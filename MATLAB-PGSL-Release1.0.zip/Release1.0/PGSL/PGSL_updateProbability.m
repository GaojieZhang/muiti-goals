% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% arg 1:  the structure ProblemSetup
% arg 2: bestIntervals an array of integers storing the index of intervals containing the best values of variables
% arg 3: A negative point - a point that is inferior to the current best
% returns the array containing the updated structure PAxis
function ret  = PGSL_updateProbability (setup, bestIntervals, negpt)

	% Algorithm
	
	
	ret = setup.axes;
	numVars = setup.numvars;
		
	for i = 1:numVars
	
		index = PAxis_indexOf(setup.axes(i), negpt(i) );
		
		if (index == bestIntervals(i) ) 
			% do not update
		else
			p1 = ret(i).prob(index) ;
			ret(i).prob(index) = p1/2;
			% fprintf( 'prob %d %d %f \n ', i, index, p1);
		end
	end

   
end
