% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% arg 1 axes:  array containing structure PAxis. 
% arg 2 pt: of type structure Point
% returns an array of integers. Each integer is the index of the interval corresponding to the value in the point pt
function ret  = PGSL_getIntervals (axes, pt)

	
	numVars = length(axes);
		
	for i = 1:numVars
	
		index = PAxis_indexOf(axes(i), pt(i) );
		ret(i) = index;
		
	end

   
end
