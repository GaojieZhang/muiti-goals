% Copyright (C) 2010 Benny Raphael

% This is an internal function of PGSL
% Inserts a new point in the sorted array of 5 best points
% argument 1 numPoints - the number of points already in the array points 
% argument 2 points - an array of structure Point. the previous points. 
% argument 3 newpoint - a new point to be added to the array
% returns the updated array of points
function ret  = PGSL_sortBestPoints (numPoints, points, newpoint)

	% The number of points taken
	numsaved = 5;
	
	% Initialise the index to the last one
	% Index is the position where the new point will be inserted
	index = numPoints+1;
	
	% Locate the position of the new point in the array
	for j=1:numPoints
		if (points(j).y > newpoint.y) 
			% Insert the new point at this index
			index = j;
			break;
		end
	end

	lastIndex = numPoints-1;
	% If we do not have enough points so far, set the number to numPoints
	if (numPoints < numsaved)
		lastIndex = numPoints;
	end
	
	% Shift all the points above index by one row
	for j=lastIndex:-1:index
		points(j+1) = points(j);
	end
	
	points(index) = newpoint;

	ret = points;	
   
end
