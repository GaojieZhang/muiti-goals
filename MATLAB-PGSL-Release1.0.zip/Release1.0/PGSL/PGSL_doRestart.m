% Copyright (C) 2010 Benny Raphael

% This is an internal routine of PGSL
% arg 1 setup: The problem setup of type structure ProblemSetup
% arg 2 minimumPoint: of type Point. the minimum point found so far
% returns the structure ProblemSetup
% 
function  ret  = PGSL_doRestart (setup, minimumPoint)

	ret = setup;
	
	savemin=0;

	if (setup.restart == 0) 
		% no previous restart
		% should save the current minimum
		savemin=1;
	else 
		if (setup.backupMinimumPoint.y > minimumPoint.y) 
			savemin=1;
		end
	end 
	
	if ( savemin > 0 ) 
		ret.backupMinimumPoint = minimumPoint;
	end
	
	ret.restart = setup.iSDC;
	ret.axes = PGSL_resetAxes(setup);

end
