% Copyright (C) 2010 Benny Raphael

% This is a test function used evaluate the performance of PGSL
function ret  = test_F8 (numvars)

	for i = 1:numvars
	    % Initialising the bounds and precision
		bmin(i) = -512;
		bmax(i) = 511;
		prec(i) = 1e-5;
	end

	% The number of evaluations
	numeval = 10000 * numvars;
	
	% The threshold of the objective function
	% Give an impossible negative number if you are not sure
	threshold = -1;
		
	% Create the ProblemSetup structure 
	setup = ProblemSetup_create( bmin, bmax, prec, numeval, threshold);
	
	% set the cost function
	setup.costFunction = @test_F8_objective;

	setup = PGSL_findMinimum(setup);

	% Print the results
	fprintf(1, ' Num eval %d\n', setup.numEvaluations);
	fprintf(1, ' Minimum found %f\n', setup.minimumPoint.y);
	fprintf(1, ' Variable values\n');
	for i=1:numvars
		fprintf(1, '%d \t %f \n', i, setup.minimumPoint.x(i) );
	end

	ret = setup;
   
end
