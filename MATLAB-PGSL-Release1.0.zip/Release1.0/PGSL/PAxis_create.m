% Copyright (C) 2010 Benny Raphael

% This is the constructor for creating the PAxis structure
% argument 1 the lower bound of the variable
% argument 2 the upper bound of the variable
% return value - the structure PAxis
function ret  = PAxis_create (min, max, precision)
	ret.min = min;
	ret.max = max;
	ret.precision = precision;
	numintervals = 20;
	dx = (max-min)/numintervals;
	p = 1.0/numintervals;
	for i = 1:numintervals
		ret.intervals(i) = min + (i-1)*dx;
		ret.prob(i) = p;
		ret.cdf(i) = (i-1)*p;
   end 

end
