% Copyright (C) 2010 Benny Raphael

% This is a test function used evaluate the performance of PGSL
function ret  = test_F8_objective (setup, x)

	numVariables = setup.numvars;
	
	total = 1;
	for i= 1:numVariables 
		x1 = x(i);
		total = total + x1*x1/4000.;
	end

	costerm = 1;
	for i= 1:numVariables 
		x1 = x(i);
		costerm = costerm*cos( x1/sqrt(i) );
	end

   total = total - costerm;

   ret = total;

end
