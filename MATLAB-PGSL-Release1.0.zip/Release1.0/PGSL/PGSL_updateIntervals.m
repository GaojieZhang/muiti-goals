% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% The function updates the intervals of the PDF, after locating a new minimum point
% arg 1:  the structure ProblemSetup
% arg 2 the current iteration in the focusing cycle. if it is zero, the previous point is dummy and is not used to update the intervals
% arg 3: Structure Point, the best point found in the previous cycle
% arg 4: the lower bound of the variable 
% arg 5: the upper bound of the variable 
% returns the array containing the updated structure PAxis
function ret  = PGSL_updateIntervals (setup, iFC, prevBestPoint, minBound, maxBound)

	% Algorithm
	
	
	ret = setup.axes;
	numVars = setup.numvars;
	pmax = numVars/(numVars + 1);
	probBestInterval = pmax * iFC/(setup.NFC+1);
	if (probBestInterval < 0.67)
		probBestInterval = 0.67;
	end
	
	for i = 1:numVars
	
		index = PAxis_indexOf(setup.axes(i), setup.minimumPoint.x(i) );
		
		if (iFC == 0) 
			mindx = 0;
		else
			mindx = abs(setup.minimumPoint.x(i) - prevBestPoint(i) );
		end
		ret(i) = PGSL_divideInterval ( ret(i), index, setup.minimumPoint.x(i), mindx, minBound(i), maxBound(i), probBestInterval );
	end

   
end
