% Copyright (C) 2010 Benny Raphael

% This is an internal function of PGSL
% Checks whether it has converged by checking the min and max of each axes
% argument 1 axes - the array containing elements of structure PAxis
% returns 1 or 0, 1 denotes converged
function ret  = PGSL_hasConverged (axes)

	numVars = length(axes);

	for i=1:numVars
		dx = axes(i).max - axes(i).min;
		if (dx > axes(i).precision) 
			ret = 0;
			return;	
		end
	end
	ret = 1;

end
