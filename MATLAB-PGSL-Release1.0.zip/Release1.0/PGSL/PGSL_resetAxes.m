% Copyright (C) 2010 Benny Raphael

% This is an internal function of PGSL
% resets the min and max of every variable to the original bounds
% argument 1 structure  ProblemSetup 
% returns the new array of axes
function ret  = PGSL_resetAxes (setup)

	ret = setup.axes;

	numVars = setup.numvars;
	
	for i=1:numVars
		prec = setup.axes(i).precision;
		ret(i) = PAxis_create(setup.lowerBounds(i), setup.upperBounds(i), prec);
	end

end
