% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% argument 1 axis - the structure representing an axis created using PAxis_create
% argument 2 index - the index of the interval
% arg 3: pvalue - the pivot value about which division takes place
% arg 4: mindx  - the minimum interval 
% arg 5: amin - the current min of the axis
% arg 6: amax - the current max of the axis
% arg 7: probBestInterval - the probability to be assigned to the best interval
% returns the structure PAxis
% the index starts from 1
function ret  = PGSL_divideInterval (axis, index, pvalue,  mindx,  amin,  amax, probBestInterval)

	% Algorithm
	%  It divides the specified interval into 6.  intervals before and after index
	% are collapsed so that the resulting total interval is still 20.  All intervals
	% are assigned equal probability so that effectively the probability within index
	% is multiplied 10 fold  

	ret = axis;
	numIntervals = length(ret.intervals);

	% nd the number of intervals into which the best interval is subdivided
	nd = 6;
	nr = numIntervals-nd;	% remaining number of intervals 
	
	if (pvalue < ret.min)  
		if (pvalue < amin) 
			pvalue = amin;
		end
		ret.min = pvalue;
		ret.intervals(1) = ret.min;
		ret.intervals(2) = (ret.intervals(1) + ret.intervals(2))/2.;
	 end

	if (pvalue > ret.max) 
		if (pvalue > amax) 
			pvalue = amax;
		end
		ret.max = pvalue;
		ret.intervals(numIntervals) = (ret.max + ret.intervals(numIntervals))/2.;
	end
		
	mdx = 0.25 * (ret.max - ret.min);
	if (mindx > mdx) 
		mindx = mdx;
	end

	x1 = ret.intervals(index);
	if (index == numIntervals) 
		x2 = ret.max;
	else 
		x2 = ret.intervals(index+1);
	end
	if (x2 - x1 < ret.precision/10) ;
		return;
	end

	dx = (x2 - x1)/2;	
	if (dx < mindx) 
			dx = mindx;
	end
		
	x1 = pvalue - dx;
	x2 = pvalue + dx;
	if (x1 < ret.min) 
		x1 = ret.min;
	end
		
	if (x2 > ret.max) 
		x2 = ret.max;
	end

	% f1 - the percentage of area in the region less than x1
	dx1 = x1 - ret.min;
	dx2 = ret.max - x2;
	if (dx1 < ret.precision/10) 
		f1 = 0;
	else 
		f1 = dx1/(dx1+dx2);
	end 
		
	% f1 - the percentage of area in the region greater than x2
	f2 = 1-f1;

	% /*  New number of intervals before x1 */
	if (dx1 < ret.precision/10) 
		n1 = 0;
	else  
		n1 = round(f1*nr);
		if (n1 < 0.1)  % To take care of stupid matlab bug that does not allow checking n1 == 0 
			n1 = 1;
		end
	end
	n2 = nr-n1;

	% pind the total probability in the best interval
	pind = probBestInterval;
	
	% p1 the total probability in the region before x1
	% p2 the total probability in the region after x2
	p1 = f1*(1 - pind);
	p2 = f2*(1 - pind);

	
	if (n1 < 0.1)  % To take care of stupid matlab bug that does not allow checking n1 == 0 
	else
		ret.intervals(1) = ret.min;
		p = p1/n1;
		ret.prob(1) =p;
	end

	% Width of main sub-interval
	dx3 = (x2 - x1)/nd;
	sf1 = 1;
	if n1 > 1 
		sf1 = (dx1/dx3)	;
	end
	if n1 > 2 
		sf1 = sf1 ^ ( 1.0/(n1-1) );
	end
	sf2 = 1;
	if n2 > 1 
		sf2 = (dx2/dx3)	;
	end
	if n2 > 2 
		sf2 = (dx2/dx3) ^ ( 1.0/(n2-1) );
	end
	
	xc = axis.min;
	for i = 2:1:n1
		dx1 = dx1 / sf1;
		ret.intervals(i) = x1 - dx1; 
		ret.prob(i) = p;
		xc = ret.intervals(i);
	end

	%   /*  Calculating the coordinates and probs of intervals between x1 and x2 */
	p = pind/nd;
	for i = 1:nd
		ret.intervals(n1+i) = x1 + (i-1)*dx3;
		ret.prob(n1+i) = p;
	end

	xc = ret.max;
	if (n2 < 0.1)  
	else 
		p = p2/n2;
		ret.prob(numIntervals) =p;
	end
	
	for i=0:1:n2-1
		dx2 = dx2 / sf2	;	
		ret.intervals(numIntervals-i) = x2 + dx2;
		ret.prob(numIntervals-i) = p;
		xc = ret.intervals(numIntervals-i);
	end

	ret.cdf = PAxis_calculateCDF(ret);
	
	% ret.intervals
	
   
end
