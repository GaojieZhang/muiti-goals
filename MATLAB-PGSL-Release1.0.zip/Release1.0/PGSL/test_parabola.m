% Copyright (C) 2010 Benny Raphael

% This is a test function used evaluate the performance of PGSL
function ret  = test_parabola ()

	bmin = [ -100 -100];
	bmax = [  100  100];
	prec = [ 0.001 0.001];

	% The number of evaluations
	numeval = 400 ;
	
	% The threshold of the objective function
	% Give an impossible negative number if you are not sure
	threshold = -1;
		
	% Create the ProblemSetup structure 
	setup = ProblemSetup_create( bmin, bmax, prec, numeval, threshold);
	
	% set the cost function
	setup.costFunction = @test_parabola_objective;

	setup = PGSL_findMinimum(setup);

	% Print the results
	fprintf(1, ' Num eval %d\n', setup.numEvaluations);
	fprintf(1, ' Minimum found %f\n', setup.minimumPoint.y);
	fprintf(1, ' Variable values\n');
	fprintf(1, 'x1 \t %f \n', setup.minimumPoint.x(1) );
	fprintf(1, 'x2 \t %f \n', setup.minimumPoint.x(2) );

	ret = setup;
   
end
