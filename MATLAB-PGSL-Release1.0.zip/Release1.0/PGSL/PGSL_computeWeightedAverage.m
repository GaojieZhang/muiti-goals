% Copyright (C) 2010 Benny Raphael

% This is an internal function of PGSL
% Returns the weighted average of the value of a variable for the past 5 points
% argument 1 axis - the index of the variable 
% argument 2 points - an array of structure Point. the previous five points. 
% return weighted average of the value of the variable
function ret  = PGSL_computeWeightedAverage (axis, points)

	% The number of points taken
	ntake = 5;

	% The index of the worst point 
	worst = ntake;
	
	% Find the sum for normalization
	sum = 0;
	for i=1:ntake
		% weight for this point
		w = points(worst).y - points(i).y;
		sum =  sum + w;      
	end
	 
	av = 0;
	for i=1:ntake
		% weight for this point
		w = points(worst).y - points(i).y;
		if ( sum < 1e-16 ) 
			w = 0.2;
		else 
			w = w/sum;
		end
		x = points(i).x(axis);
		av = av + x*w;
	end

   ret = av;	
   
end
