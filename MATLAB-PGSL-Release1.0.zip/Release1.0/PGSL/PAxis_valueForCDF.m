% Copyright (C) 2010 Benny Raphael

% This function returns the value of the variable for a specified value of cdf
% argument 1 axis - the structure representing an axis created using PAxis_create
% argument 2 t - the value of the cdf
% return value of the variable for the specified cdf
function ret  = PAxis_valueForCDF (axis, t)

	numIntervals = length(axis.intervals);
	found = 0;

	for i=1:numIntervals
		if (t < axis.cdf(i)) 
			found = 1;
			break
		end
   end 
   
   
	if (i==1) 
		ret = axis.intervals(1);
		return;
	end 
	
	if (found == 0) 
		t1 = axis.cdf(numIntervals);
		x1 = axis.intervals(numIntervals);
		t2 = 1.0;
		x2 = axis.max;
	else 
		t1 = axis.cdf(i-1);
		x1 = axis.intervals(i-1);
		t2 = axis.cdf(i);
		x2 = axis.intervals(i);
	end
	
	dt = t - t1;
	deltat = t2-t1;
	if (deltat < 1e-6)
		ret = x1;
	else
		ret = x1 + dt*(x2 - x1)/deltat;
	end

end
