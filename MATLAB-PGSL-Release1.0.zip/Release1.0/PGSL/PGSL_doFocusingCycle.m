% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% It performs the focusing cycle
% argument 1: structure ProblemSetup
% argument 2: array containing lower bounds of variables
% argument 3: array containing upper bounds of variables
% argument 4: the starting point
% returns the updated ProblemSetup structture
function ret  = PGSL_doFocusingCycle (setup, minBound, maxBound, startPoint)

	ret = setup;
	
	NFC = ret.NFC;
	NS = ret.NS;
	numVars = ret.numvars;
	numIntervals = length(setup.axes(1).intervals);
	
	fcbest = startPoint;
	ret.minimumPoint = startPoint;
	pt = startPoint;
	bestIntervals = PGSL_getIntervals( setup.axes, pt.x);
	
	for iFC = 1:NFC

		if ret.numEvaluations > ret.maxNumEvaluations 
			break
		end
		
		ret.iFC = iFC;
	
		% Saving the previous known minimum cost value
		oldcost = ret.minimumPoint.y;
     
		for iS=1:NS
		
			if ret.numEvaluations > ret.maxNumEvaluations 
				break
			end

		ret.iS = iS;

			% Generating a solution point consisting of values for all variables
			pt = PGSL_generatePoint(ret, pt);
			ret.numEvaluations = ret.numEvaluations +1;
			
			% Updating the best known solution point
			if ret.minimumPoint.y > pt.y 
				ret.minimumPoint = pt;
				bestIntervals = PGSL_getIntervals( ret.axes, pt.x);
				nnn = round(ret.numEvaluations);
				% fprintf(1, '        %d %f \t %d %f %f\n', nnn, pt.y, ret.iSDC, pt.x(1), pt.x(2) );
			else
				if ret.NPUC > 1
					% Update probabilities
					for i = 1:numVars				
						index = PAxis_indexOf(ret.axes(i), pt.x(i) );					
						if (index ~= bestIntervals(i) ) 
							p1 = ret.axes(i).prob(index) ;
							ret.axes(i).prob(index) = p1/2;
							% fprintf( 'prob %d %d %f \n ', i, index, p1);
							
							% computing the cdf
							total = 0;
							for kk = 1:numIntervals
								ret.axes(i).cdf(kk) = total;
								total = total + ret.axes(i).prob(kk);
								% fprintf( 'cdf %d %f %f \n ', kk, ret.axes(i).intervals(kk), ret.axes(i).cdf(kk));
							end
							ret.axes(i).cdf = ret.axes(i).cdf/total;

						end
					end
				end 

			end
			
			% Checking terminating condition
			if (ret.minimumPoint.y <= ret.threshold) 
				break;
			end

		
		end  %  end of NS

		% Checking terminating condition
		if (ret.minimumPoint.y <= ret.threshold) 
			break;
		end
		
		if ret.minimumPoint.y < oldcost 
			% Update the pdf by changing the axis intervals to foolow an exponentially decaying distribution
			ret.axes = PGSL_updateIntervals(ret, ret.iFC-1, fcbest.x, minBound, maxBound); % The next statement should come  necessarily after this - do not change the order		
			fcbest = ret.minimumPoint;
		end

	end % end  of fc  */
	
	
	% Checking terminating condition
	if (ret.minimumPoint.y <= ret.threshold) 
				return;
	end

	
	% V4 sampling
	for i = 1:numVars				
		xmin(i) = ret.axes(i).min;
		xmax(i) = ret.axes(i).max;
	end
	
	pt = ret.minimumPoint;
	nums = 0;
	while(1)  % -------------------------- Loop 2

		if ret.numEvaluations > ret.maxNumEvaluations 
			break
		end
		
		if (nums >= NFC)
			break;
		end

		for i = 1:numVars

			if ret.numEvaluations > ret.maxNumEvaluations 
				break
			end
		
			if (nums >= NFC)
				break;
			end
			
			t = rand;
			x0 = xmin(i) + t * (xmax(i) - xmin(i));
			if ( abs(x0 - ret.minimumPoint.x(i) ) < ret.axes(i).precision )
				continue;
			end
			
			xold = pt.x(i);
			pt.x(i) = x0;
			pt.y = setup.costFunction(setup, pt.x);
			ret.numEvaluations = ret.numEvaluations +1;
			if ret.minimumPoint.y > pt.y 
				ret.minimumPoint = pt;
				% fprintf(1, 'v4s     %d %f \t %d %d \n', ret.numEvaluations, pt.y, ret.iSDC, i);
			else
				if x0 < ret.minimumPoint.x(i) 
					xmin(i) = x0;
				else
					xmax(i) = x0;
				end
				pt.x(i) = xold;
			end
			nums = nums+1;
			
			if (ret.minimumPoint.y <= ret.threshold) 
				break;
			end
			
		end

		if (nums >= NFC)
			break;
		end
		
		converged = 1;
		for i = 1:numVars
			if xmax(i) - xmin(i)  > 2*ret.axes(i).precision 
				converged = 0;
			end
		end
		if converged 
			break;
		end

	end  % end while loop 2
	
   
end
