% Copyright (C) 2010 Benny Raphael

% This function returns the index of the interval in which a number lies
% argument 1 axis - the structure representing an axis created using PAxis_create
% argument 2 x - the value of the variable that is to be located in an interval
% return value the index of the interval in which the number lies. 
% the index starts from 1
function ret  = PAxis_indexOf (axis, x)

	numIntervals = length(axis.intervals);
	
	found = 0;

	for i=1:numIntervals
		if (x < axis.intervals(i)) 
			found = 1;
			break
		end
   end 
   
   
	if (found==0) 
		% the number might be outside the upper bound. Still return the last interval
		ret = numIntervals;
	else
		if (i == 1) 
			% the number is less than the lower bound. Still return the first interval
			ret = 1;
		else
			ret = i-1;
		end
	end
	
   
end
