% Copyright (C) 2010 Benny Raphael

% This function computes the cdf of a PDF
% argument 1 axis - the structure representing an axis created using PAxis_create
% returns : the cdf as an array
function ret  = PAxis_calculateCDF (axis)

	numIntervals = length(axis.prob);
	
	total = 0;
	for i = 1:numIntervals
		ret(i) = total;
		total = total + axis.prob(i);
	end
	
	ret = ret/total;

end
