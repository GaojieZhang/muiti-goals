% Copyright (C) 2010 Benny Raphael

% This function is an internal routine of PGSL
% It generates a random soluiton point according to the current pdf
% argument 1: structure ProblemSetup
% returns the point - of type structure Point
function ret  = PGSL_generatePoint (setup, point)

	numVars = setup.numvars;
	ret = point;
	
	% Generating a solution point consisting of values for all variables
	for j = 1:numVars
		t = rand;
		ret.x(j) = PAxis_valueForCDF(setup.axes(j), t);
	end
			
	% Evaluating the point by calling the user defined objective function
	ret.y = setup.costFunction(setup, ret.x);
   
end
