% Copyright (C) 2010 Benny Raphael

% This function updates the minimum point found so far
% argument 1: structure ProblemSetup
% argument 2: newpoint - new point that has been evaluated
% returns the minimum point found so far
% Before calling this function, the variable setup.numEvaluations should be incremented
function ret  = ProblemSetup_updateMinimum (setup, newpoint)

	ret = setup.minimumPoint

   if (setup.numEvaluations <= 1) 
      ret = newpoint;	 
      return;
   end
   if (newpoint.y < setup.minimumPoint.y) 
      ret = newpoint;	 
   end
   
end
