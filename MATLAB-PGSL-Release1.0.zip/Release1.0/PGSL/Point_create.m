% Copyright (C) 2010 Benny Raphael

% This is the constructor for creating the Point structure
% argument 1 : the number of variables
% return value - the structure Point
function ret  = Point_create (numvars)

	% The array containing the optimization variables
	ret.x = zeros(numvars,1);
	
	% The evaluation of the point 
	ret.y = 0;
end
