% Copyright (C) 2010 Benny Raphael

% This is an internal function of PGSL
% reduces the subdomain size
% argument 1 structure  ProblemSetup 
% arg 2: previous best points
% arg 3: number of previous best points saved
% returns the new ProblemSetup.axes
function ret  = PGSL_narrowDown (setup, points, numpoints)

	ret = setup.axes;

	numVars = setup.numvars;

	% half the scale factor
	scf = 0.35;

	for i=1:numVars
		xp = points(1).x(i);
		dx = setup.axes(i).max - setup.axes(i).min;
		dx = dx * scf;

		if (numpoints >= 5) 
			avg = PGSL_computeWeightedAverage(i, points);
			df = abs(avg - xp) *2;
			if (df > dx) 
				dx = df;
			end
		end

		if (numpoints > 1) 
			df = 1.5*abs( points(1).x(i) - points(2).x(i) );
			if (df > dx) 
				dx = df;
			end
		end

		x1 = xp - dx;
		if (x1 < setup.lowerBounds(i)) 
			x1 = setup.lowerBounds(i);
			x2 = x1 + 2*dx;
		else 
			x2 = xp + dx;
		end
		
		if ( x2 > setup.upperBounds(i) ) 
			x2 = setup.upperBounds(i);
		end
		dx = x2 - x1;

		prec = setup.axes(i).precision;
		ret(i) = PAxis_create(x1, x2, prec);
	end
			
end
